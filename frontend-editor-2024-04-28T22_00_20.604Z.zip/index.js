let estoque = {};

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('adicionarItemBtn').addEventListener('click', adicionarItem);
});

function adicionarItem() {
    const nomeItem = document.getElementById('item').value.trim();
    const quantidade = parseInt(document.getElementById('quantidade').value);

    if (nomeItem === '' || isNaN(quantidade) || quantidade <= 0) {
        alert('Por favor, insira um nome de item válido e uma quantidade positiva.');
        return;
    }

    estoque[nomeItem] = (estoque[nomeItem] || 0) + quantidade;

    exibirEstoque();
    limparFormulario();
}

function exibirEstoque() {
    const estoqueDiv = document.getElementById('estoque');
    estoqueDiv.innerHTML = '<h2>Estoque:</h2>';

    Object.entries(estoque).forEach(([item, quantidade]) => {
        const itemHtml = `<div class="item"><p><strong>${item}:</strong> ${quantidade}</p></div>`;
        estoqueDiv.innerHTML += itemHtml;
    });
}

function limparFormulario() {
    document.getElementById('item').value = '';
    document.getElementById('quantidade').value = '';
}
