# Aplicativo de Administração de Estoque

Este é um exemplo básico de um aplicativo de administração de estoque implementado em Python.

## Funcionalidades

- Adicionar itens ao estoque com suas respectivas quantidades.
- Exibir o estoque atual.
- Excluir itens do estoque.

## Implementação em Python

```python
estoque = {}

def adicionar_item(nome, quantidade):
    if nome in estoque:
        estoque[nome] += quantidade
    else:
        estoque[nome] = quantidade

def deletar_item(nome):
    if nome in estoque:
        del estoque[nome]
    else:
        print("O item não está no estoque.")

def exibir_estoque():
    print("Estoque:")
    for item, quantidade in estoque.items():
        print(f"{item}: {quantidade}")

# Exemplo de uso
adicionar_item("Maçã", 10)
adicionar_item("Banana", 15)
exibir_estoque()

deletar_item("Maçã")
exibir_estoque()

